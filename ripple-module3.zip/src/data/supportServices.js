/**
 * Module 3 — MOCK support-service directory.
 * Represents fragmented university support services for the demo.
 * Availability and wait times are SYNTHETIC and deterministic — NOT real.
 *
 * Domains use only the shared terminology:
 *   Career Support        → ACADEMIC
 *   Accommodation Support → FINANCIAL
 *   Disability Support    → ACADEMIC
 */

const supportDirectory = [
  { supportId: "SUP001", name: "Academic Advisor",      domain: "ACADEMIC",  availability: "TODAY",     waitMinutes: 30,    status: "AVAILABLE" },
  { supportId: "SUP002", name: "Counselling",           domain: "EMOTIONAL", availability: "3_DAYS",    waitMinutes: 4320,  status: "AVAILABLE" },
  { supportId: "SUP003", name: "Peer Support",          domain: "SOCIAL",    availability: "TODAY",     waitMinutes: 15,    status: "AVAILABLE" },
  { supportId: "SUP004", name: "Financial Support",     domain: "FINANCIAL", availability: "TOMORROW",  waitMinutes: 1440,  status: "AVAILABLE" },
  { supportId: "SUP005", name: "Accommodation Support", domain: "FINANCIAL", availability: "NEXT_WEEK", waitMinutes: 10080, status: "UNAVAILABLE" },
  { supportId: "SUP006", name: "Wellbeing Advisor",     domain: "PERSONAL",  availability: "TODAY",     waitMinutes: 60,    status: "AVAILABLE" },
  { supportId: "SUP007", name: "Career Support",        domain: "ACADEMIC",  availability: "2_DAYS",    waitMinutes: 2880,  status: "AVAILABLE" },
  { supportId: "SUP008", name: "Disability Support",    domain: "ACADEMIC",  availability: "2_DAYS",    waitMinutes: 2880,  status: "AVAILABLE" },
];

/**
 * Routing map: which services are APPROPRIATE for each domain.
 * Counselling appears only as a later option for some domains — never the default.
 */
const domainRouting = {
  ACADEMIC:  ["SUP001", "SUP003", "SUP007", "SUP002"],
  EMOTIONAL: ["SUP006", "SUP003", "SUP002"],
  SOCIAL:    ["SUP003", "SUP006"],
  FINANCIAL: ["SUP004", "SUP005"],
  PERSONAL:  ["SUP006", "SUP003", "SUP002"],
};

module.exports = { supportDirectory, domainRouting };
