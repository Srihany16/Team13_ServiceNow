/**
 * Module 3 — in-memory support connections (the ONLY student data Module 3 owns).
 * Pressure / wellbeing / ripple / social come from Modules 1 and 2.
 * Resets on server restart (by design — no database).
 *
 * connection status: OFFERED | ACTIVE | COMPLETED | DECLINED
 */

const supportState = {
  STU001: { connections: [] },
  STU002: {
    connections: [{ supportId: "SUP001", status: "ACTIVE", notes: "Ongoing academic check-ins.", updatedAt: "2026-09-28T09:00:00.000Z" }],
  },
  STU003: { connections: [] },
};

// Mock friend-first check-in offers. No real messaging is ever sent.
const friendRequests = {};

module.exports = { supportState, friendRequests };
