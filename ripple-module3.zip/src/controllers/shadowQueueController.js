/**
 * Module 3 — shadowQueueController (thin: call service, format response).
 */

const { detectShadowQueue } = require("../services/shadowQueueService");

const ok = (res, data) => res.status(200).json({ success: true, data, error: null });

const fail = (res, err) => {
  const status = err && err.status ? err.status : 500;
  const message = err && err.status ? err.message : "Internal server error";
  return res.status(status).json({ success: false, data: null, error: message });
};

function getShadowQueue(req, res) {
  try {
    const students = detectShadowQueue();
    ok(res, { students, total: students.length });
  } catch (err) {
    fail(res, err);
  }
}

module.exports = { getShadowQueue, ok, fail };
