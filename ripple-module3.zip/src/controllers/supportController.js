/**
 * Module 3 — supportController (thin: call service, format response).
 * Validation rules live in supportService so they're testable without HTTP.
 */

const supportService = require("../services/supportService");
const profileService = require("../services/profileService");
const { ok, fail } = require("./shadowQueueController");

const handle = (fn) => (req, res) => {
  try {
    ok(res, fn(req));
  } catch (err) {
    fail(res, err);
  }
};

const getSupport = handle((req) => {
  const { studentId, recommendedDomain, recommendedAction, fastestOption, services } =
    supportService.recommendSupport(req.params.studentId);
  return { studentId, recommendedDomain, recommendedAction, fastestOption, services };
});

const getProfile = handle((req) => profileService.getStudentSupportProfile(req.params.studentId));

const postSupportAction = handle((req) => supportService.createSupportAction(req.params.studentId, req.body));

const postFriendSupport = handle((req) => supportService.createFriendSupportRequest(req.params.studentId, req.body));

module.exports = { getSupport, getProfile, postSupportAction, postFriendSupport, fail };
