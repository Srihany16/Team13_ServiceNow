/**
 * Module 3 — shadowQueueService
 * Shadow Queue = students showing repeated signs that support may help,
 * who are NOT currently connected to active support.
 * NOT a diagnosis, NOT a crisis classification, NOT a medical judgement.
 *
 * RULE (all three must hold):
 *   A. Concerning change:   wellbeing trend DECLINING  OR  Module 2 ripple detected
 *   B. Extra signal:        pressure HIGH  OR  ripple severity MEDIUM/HIGH
 *                           OR  support OFFERED/DECLINED (not accepted)
 *   C. Not connected:       support status is NOT ACTIVE
 *
 * Severity = Module 2 ripple severity (no new scoring); LOW if no ripple.
 * Recalculated on every request — membership is never stored.
 */

const supportService = require("./supportService");

function evaluateStudent(studentId) {
  const signals = supportService.getStudentSignals(studentId);
  const supportStatus = supportService.getSupportStatus(studentId);
  const { pressure, wellbeing, ripple, social } = signals;

  const notAccepted = supportStatus === "OFFERED" || supportStatus === "DECLINED";
  const conditionA = wellbeing.trend === "DECLINING" || ripple.rippleDetected;
  const conditionB =
    pressure.forecast === "HIGH" || ["MEDIUM", "HIGH"].includes(ripple.severity) || notAccepted;
  const conditionC = supportStatus !== "ACTIVE";

  const reason = [];
  if (wellbeing.trend === "DECLINING") reason.push("Repeated declining trend");
  if (ripple.rippleDetected && ripple.changedDomains.length) {
    reason.push(`Change detected in ${ripple.changedDomains.join(", ")} domain(s)`);
  }
  if (pressure.forecast === "HIGH") reason.push("High upcoming academic pressure");
  if (social && social.trend === "DECLINING") reason.push("Fewer collaboration interactions than usual");
  if (supportStatus === "DECLINED") reason.push("Support recommendation not accepted");
  if (supportStatus === "OFFERED") reason.push("Support offered but not yet accepted");
  if (supportStatus === "NOT_CONNECTED" || supportStatus === "COMPLETED") reason.push("No active support connection");

  const routing = supportService.recommendSupport(studentId);
  const inQueue = conditionA && conditionB && conditionC;

  return {
    studentId,
    status: inQueue ? "SHADOW_QUEUE" : "NOT_IN_QUEUE",
    severity: inQueue ? ripple.severity || "LOW" : null,
    reason: inQueue ? reason : [],
    recommendedDomain: routing.recommendedDomain,
    recommendedAction: routing.recommendedAction,
  };
}

/** detectShadowQueue(studentIds?) → students currently in the Shadow Queue. */
function detectShadowQueue(studentIds = supportService.getAllStudentIds()) {
  return studentIds.map(evaluateStudent).filter((s) => s.status === "SHADOW_QUEUE");
}

module.exports = { detectShadowQueue, evaluateStudent };
