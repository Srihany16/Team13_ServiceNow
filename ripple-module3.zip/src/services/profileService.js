/**
 * Module 3 — profileService
 * Unified Student Support Profile for AUTHORIZED SUPPORT STAFF.
 * Assembled from Module 1 + 2 outputs and Module 3 state. No new calculations.
 *
 * Privacy: only summary levels/trends are exposed — no weekly history,
 * no social counts, no notes, no messages, no location.
 */

const supportService = require("./supportService");
const { evaluateStudent } = require("./shadowQueueService");

function getStudentSupportProfile(studentId) {
  const signals = supportService.getStudentSignals(studentId);
  const ranked = supportService.getRankedDomains(signals);
  const routing = supportService.recommendSupport(studentId);
  const shadow = evaluateStudent(studentId);

  return {
    studentId,
    pressure: { forecast: signals.pressure.forecast, score: signals.pressure.score },
    wellbeing: { overallLevel: signals.wellbeing.overallLevel, trend: signals.wellbeing.trend },
    ripple: {
      rippleDetected: signals.ripple.rippleDetected,
      severity: signals.ripple.severity,
      recommendedAction: signals.ripple.recommendedAction,
    },
    domains: { primary: ranked[0] || null, secondary: ranked[1] || null },
    support: {
      status: supportService.getSupportStatus(studentId),
      currentServices: supportService.getCurrentServices(studentId),
      recommendedService: routing.recommendedService,
    },
    shadowQueue: { status: shadow.status, severity: shadow.severity },
  };
}

module.exports = { getStudentSupportProfile };
