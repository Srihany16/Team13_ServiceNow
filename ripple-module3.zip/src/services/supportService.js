/**
 * Module 3 — supportService
 * Consumes Module 1 + 2 signals (read-only), routes students to support,
 * records support actions and friend-first check-in offers.
 * No diagnosis, no clinical recommendations, no real messaging.
 */

const pressureService = require("./pressureService"); // Module 1
const wellbeingService = require("./wellbeingService"); // Module 2
const rippleService = require("./rippleService"); // Module 2
const socialService = require("./socialService"); // Module 2
const { supportDirectory, domainRouting } = require("../data/supportServices");
const { supportState, friendRequests } = require("../data/supportState");

class SupportError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

const LEVEL_RANK = { LOW: 1, MEDIUM: 2, HIGH: 3 };
const ACTION_TO_STATUS = { ASSIGN: "ACTIVE", OFFER: "OFFERED", DECLINE: "DECLINED", COMPLETE: "COMPLETED" };
const CONSENT_REQUIRED = ["ASSIGN", "OFFER"];
const CONTACT_TYPES = ["FRIEND"];
const MESSAGE_TYPES = ["SIMPLE_CHECK_IN"];

// ---------- signals (consumed, never recalculated) ----------

/**
 * Collects Module 1 + 2 outputs for one student.
 * A student is valid only if BOTH Module 1 and Module 2 know them.
 */
function getStudentSignals(studentId) {
  const pressure = pressureService.generatePressureForecast(studentId); // null if unknown
  let matrix = null;
  try {
    matrix = wellbeingService.getWellbeingMatrix(studentId); // throws if unknown
  } catch (e) {
    matrix = null;
  }
  if (!pressure || !matrix) throw new SupportError("Student not found", 404);

  return {
    pressure,
    wellbeing: {
      overallLevel: matrix.overallLevel,
      trend: wellbeingService.calculateWellbeingTrend(wellbeingService.getOverallHistory(studentId)),
      domains: matrix.domains,
    },
    ripple: rippleService.detectRipple(studentId),
    social: socialService.getSocialSignal(studentId), // may be null
  };
}

/** All students known to both modules. */
function getAllStudentIds() {
  return Object.keys(supportState).filter((id) => {
    try {
      getStudentSignals(id);
      return true;
    } catch (e) {
      return false;
    }
  });
}

/**
 * Domain ranking rule:
 *   1. Domains Module 2's ripple flagged as changed (in its order).
 *   2. Then other domains currently at MEDIUM/HIGH strain, highest first.
 *   LOW-strain domains are never a support need.
 */
function getRankedDomains(signals) {
  const ranked = [...signals.ripple.changedDomains];
  Object.entries(signals.wellbeing.domains)
    .filter(([d, level]) => level !== "LOW" && !ranked.includes(d))
    .sort((a, b) => LEVEL_RANK[b[1]] - LEVEL_RANK[a[1]])
    .forEach(([d]) => ranked.push(d));
  return ranked;
}

// ---------- support state ----------

function getConnections(studentId) {
  if (!supportState[studentId]) supportState[studentId] = { connections: [] };
  return supportState[studentId].connections;
}

/** ACTIVE if any connection is active; else most recent connection's status; else NOT_CONNECTED. */
function getSupportStatus(studentId) {
  const connections = getConnections(studentId);
  if (connections.some((c) => c.status === "ACTIVE")) return "ACTIVE";
  if (connections.length === 0) return "NOT_CONNECTED";
  return connections[connections.length - 1].status;
}

function getCurrentServices(studentId) {
  return getConnections(studentId)
    .filter((c) => c.status === "ACTIVE")
    .map((c) => c.supportId);
}

// ---------- routing ----------

/**
 * recommendSupport(studentId)
 * NEED → DOMAIN → APPROPRIATE SERVICES → AVAILABLE ONLY → SORT BY WAIT → FASTEST
 *   recommendedService = the domain's own specialist if available (e.g. Academic Advisor)
 *   fastestOption      = shortest wait among appropriate available services
 */
function recommendSupport(studentId) {
  const signals = getStudentSignals(studentId);
  const recommendedDomain = getRankedDomains(signals)[0] || null;

  if (!recommendedDomain) {
    return {
      studentId,
      recommendedDomain: null,
      recommendedAction: "NO_ACTION",
      recommendedService: null,
      fastestOption: null,
      services: [],
    };
  }

  const services = domainRouting[recommendedDomain]
    .map((id) => supportDirectory.find((s) => s.supportId === id))
    .filter((s) => s && s.status === "AVAILABLE")
    .sort((a, b) => a.waitMinutes - b.waitMinutes)
    .map(({ supportId, name, availability, waitMinutes, status }) => ({ supportId, name, availability, waitMinutes, status }));

  const specialist = services.find(
    (s) => supportDirectory.find((d) => d.supportId === s.supportId).domain === recommendedDomain
  );

  return {
    studentId,
    recommendedDomain,
    recommendedAction: `${recommendedDomain}_CHECK_IN`,
    recommendedService: specialist ? specialist.supportId : services[0] ? services[0].supportId : null,
    fastestOption: services[0] ? services[0].supportId : null,
    services,
  };
}

// ---------- actions ----------

/**
 * createSupportAction(studentId, { supportId, action, notes, consent })
 *   ASSIGN → ACTIVE, OFFER → OFFERED, DECLINE → DECLINED, COMPLETE → COMPLETED
 * Consent rule: ASSIGN and OFFER need consent === true (never assumed).
 * Updates in-memory state, so the Shadow Queue recalculates on the next request.
 */
function createSupportAction(studentId, body = {}) {
  getStudentSignals(studentId); // "Student not found"
  const { supportId, action, notes, consent } = body || {};

  if (!supportId || !action) throw new SupportError("Missing required field");
  if (!ACTION_TO_STATUS[action]) throw new SupportError("Invalid action");
  const service = supportDirectory.find((s) => s.supportId === supportId);
  if (!service) throw new SupportError("Support service not found", 404);
  if (consent !== undefined && typeof consent !== "boolean") throw new SupportError("Invalid consent");
  if (CONSENT_REQUIRED.includes(action) && consent !== true) {
    throw new SupportError("Consent is required for this action", 403);
  }
  if (CONSENT_REQUIRED.includes(action) && service.status !== "AVAILABLE") {
    throw new SupportError("Support service unavailable", 409);
  }
  if (notes !== undefined && (typeof notes !== "string" || notes.length > 500)) {
    throw new SupportError("Invalid notes");
  }

  const connections = getConnections(studentId);
  const existing = connections.find((c) => c.supportId === supportId);
  if (action === "COMPLETE" && (!existing || existing.status !== "ACTIVE")) {
    throw new SupportError("No active support connection to complete", 409);
  }

  const status = ACTION_TO_STATUS[action];
  const record = { supportId, status, notes: notes || "", updatedAt: new Date().toISOString() };
  if (existing) connections.splice(connections.indexOf(existing), 1);
  connections.push(record); // most recent last

  const messages = {
    ASSIGN: "Support connection created.",
    OFFER: "Support has been offered.",
    DECLINE: "Support offer recorded as declined.",
    COMPLETE: "Support connection marked as completed.",
  };

  return { studentId, supportId, status, action, message: messages[action] };
}

/**
 * createFriendSupportRequest(studentId, { contactType, consent, messageType })
 * Mock only — nothing is sent. The output NEVER contains wellbeing, pressure,
 * ripple or Shadow Queue information; only a neutral check-in template.
 */
function createFriendSupportRequest(studentId, body = {}) {
  getStudentSignals(studentId); // "Student not found"
  const { contactType, consent, messageType } = body || {};

  if (!contactType || !messageType || consent === undefined) throw new SupportError("Missing required field");
  if (!CONTACT_TYPES.includes(contactType)) throw new SupportError("Invalid contactType");
  if (!MESSAGE_TYPES.includes(messageType)) throw new SupportError("Invalid messageType");
  if (consent !== true) throw new SupportError("Consent is required for this action", 403);

  const request = {
    studentId,
    contactType,
    status: "OFFERED",
    message: "A simple check-in can be sent without sharing sensitive wellbeing information.",
    checkInTemplate: "Hey, haven't checked in with you lately. Want to grab a coffee this week?",
  };
  friendRequests[studentId] = { contactType, messageType, status: "OFFERED", createdAt: new Date().toISOString() };
  return request;
}

module.exports = {
  SupportError,
  getStudentSignals,
  getAllStudentIds,
  getRankedDomains,
  getSupportStatus,
  getCurrentServices,
  recommendSupport,
  createSupportAction,
  createFriendSupportRequest,
};
