/**
 * Module 3 — Shadow Queue route. Mount with: app.use("/api", shadowQueueRoutes);
 */

const express = require("express");
const controller = require("../controllers/shadowQueueController");

const router = express.Router();

router.get("/shadow-queue", controller.getShadowQueue);

module.exports = router;
