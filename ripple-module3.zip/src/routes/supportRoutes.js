/**
 * Module 3 — support routes. Mount with: app.use("/api", supportRoutes);
 */

const express = require("express");
const controller = require("../controllers/supportController");

const router = express.Router();
router.use(express.json());

router.get("/students/:studentId/support", controller.getSupport);
router.get("/students/:studentId/profile", controller.getProfile);
router.post("/students/:studentId/support/action", controller.postSupportAction);
router.post("/students/:studentId/friend-support", controller.postFriendSupport);

// eslint-disable-next-line no-unused-vars
router.use((err, req, res, next) => {
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ success: false, data: null, error: "Invalid JSON body" });
  }
  return controller.fail(res, err);
});

module.exports = router;
